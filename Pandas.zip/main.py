from cliente import Cliente
import pandas as pd

# Aqui é criado o dataFrame - Um pseudo banco de dados
pandas_dataframe = pd.DataFrame({ "ID":[1,2], "Name":["Matheus", "Raquel"], "CPF":["000.000.000-00", "111.111.111-111"], "RG":["00.000.000-0","0.000.000-0"],
                     "tem_conta":[False, False], "Conta":["NULL", "NULL"], "Saldo":[1125.52,950.95]})

# Operações básicas de pesquisa
print(pandas_dataframe,"\n")
print(pandas_dataframe["CPF"])
print(pandas_dataframe["Saldo"].max())
print(pandas_dataframe.describe())

# Exportar para o excel
pandas_dataframe.to_excel("planilhas/Clientes.xlsx", sheet_name="Contas", index=False)

# Ler um arquivo .json
df = pd.read_json("JSON/bancos.json", orient="split")
print(df)

print(df["Banco"][0])
print(df["Código"][0])
print(df["Clientes"][0])

# Export para o excel
df.to_excel("planilhas/Bancos.xlsx", sheet_name="Bancos Cadastrados", index=False)